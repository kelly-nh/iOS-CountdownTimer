# Timer

List of sources that I followed to create this project

**Gradient Background Color** 
https://github.com/Bilguun132/Core-Animations
https://www.hackingwithswift.com/books/ios-swiftui/counting-down-with-a-timer
https://medium.com/@bilguun132/beautifying-your-ios-app-with-core-animation-fec66cc3fced

**Countdown Timer:**
https://github.com/dgreenheck/simple-pomodoro-ios
https://www.hackingwithswift.com/books/ios-swiftui/counting-down-with-a-timer
http://www.popcornomnom.com/countdown-timer-in-swift-5-for-ios/




